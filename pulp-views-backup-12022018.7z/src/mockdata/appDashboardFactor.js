const app_dashboard_factor_data = [
  { date: "4/16/2018", factor: 9.2 },
  { date: "10/10/2018", factor: 8.4 },
  { date: "2/5/2018", factor: 8.4 },
  { date: "7/28/2018", factor: 8.7 },
  { date: "10/20/2018", factor: 8.1 },
  { date: "8/11/2018", factor: 8.5 },
  { date: "8/27/2018", factor: 9.2 },
  { date: "8/15/2018", factor: 9.5 },
  { date: "2/2/2018", factor: 8.9 },
  { date: "2/2/2018", factor: 9.6 }
];

export { app_dashboard_factor_data };
